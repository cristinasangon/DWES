/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/JSP_Servlet/Servlet.java to edit this template
 */
package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author crisc
 */
public class ServletValida extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ServletContext contexto = getServletContext();
        RequestDispatcher rd;

        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();

        // Obtener el usuario del atributo
        String usuario = (String) request.getAttribute("usuario");
        if (usuario == null) {
            usuario = request.getParameter("usuario");  // Si es null, obtener del parámetro
        }

        // Procesamiento de la actividad
        String nombreActividad = request.getParameter("nombreActividad");
        String lugarActividad = request.getParameter("lugarActividad");
        String fechaActividad = request.getParameter("fechaActividad");
        String horaActividad = request.getParameter("horaActividad");
        String destinada = request.getParameter("destinada");
        String[] tipoActividad = request.getParameterValues("tipoActividad");
        String curso = request.getParameter("curso");
        String profesor = request.getParameter("profesor");
        String observaciones = request.getParameter("observaciones");

        boolean valido = true;

        // Validaciones (sin cambios)
        // ...

        if (valido) {
            // Asegurarse de pasar el atributo usuario a la JSP
            request.setAttribute("usuario", usuario);
            rd = contexto.getRequestDispatcher("/actividadExtraescolas.jsp");
            rd.forward(request, response);
        } else {
            rd = contexto.getRequestDispatcher("/errorActividad.html");
            rd.forward(request, response);
        }
    }

}
